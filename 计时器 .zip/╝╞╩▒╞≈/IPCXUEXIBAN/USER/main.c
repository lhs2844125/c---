/*
 * @Author: IPC15-???
 * @Date: 2023-11-1 20:55:18
 * @LastEditTime: 2023-11-1 20:55:18
 * @FilePath: \USER\main.c
 * @custom_steing_obkoro1:  Read only, do not modify place!!!
 */
#include "sys.h" //The <lwoopc.h> is already included here
#include "delay.h"
#include "usart.h"
//#include "usart2.h"	
#include "led.h"
#include "stdio.h"
#include "math.h"
#include "OLED.h"
#include "bee.h"  
#include "w25q128.h"
#include "HMC5883L.h"
#include "math.h"
#include "icm20602.h"
#include "bmi088.h"
#include "bmp280.h"
#include "exti.h"  
#include "TIM.H"

	
 
int main(void)
{
	delay_init(168);
	LED_Init();
	Bee_Init();
	TIM3_Init();
	OLED_Init();
	uint16_t m=0;
	uint16_t h=0;
	

  while(1){
	  if(s>=60)
	  {
		  m++;
		  s=0;
	  }
	  if(s>=60)
	  {
		  h++;
		  m=0;
	  }
	  	  if(h>=60)
	  {
		  h=0;
	  }
	  OLED_ShowNum( 1, 1, h, 2);
	  OLED_ShowChar( 1, 3, ':');
	  OLED_ShowNum( 1, 4, m, 2);
	   OLED_ShowChar( 1, 6, ':');
	  OLED_ShowNum( 1, 7, s, 2);
	
	}
}
