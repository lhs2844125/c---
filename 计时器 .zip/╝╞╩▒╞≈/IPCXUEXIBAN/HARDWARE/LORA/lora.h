#ifndef __LORA_H
#define __LORA_H
#include "sys.h"



void LoRa_Process(void);
void LoRa_SendData(void);
void LoRa_ReceData(void);
void Lora_Test(void);

#endif

