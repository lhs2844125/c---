#ifndef __USART_H_
#define __USART_H_
#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 
	

void USART2_ITconfig(void);

#endif


