#include "exti.h"  
#include "led.h" 
#include "bee.h"  
// ??:??IO????
//
void exti_Init(void)
{		
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);  //??????,???? EXTI ?APB2???
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);  //GPIO???
	
	GPIO_InitTypeDef GPIO_InitStructure; //???
	EXTI_InitTypeDef EXTI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4; //????
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN; //????
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  //????
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource3); //PD3??????	
	/* ??exit3???? */	
	EXTI_InitStructure.EXTI_Line = EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//????
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; // ?????
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOD, EXTI_PinSource4);
	/* ??exit4???? */		
	EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;//????
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling; // ?????
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;//????3
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00; // ?????????
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00; // ?????????
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00; // ?????????
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00; // ?????????
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);	
}

	unsigned char LED1n=0;
	unsigned char mode=0;
void EXTI3_IRQHandler(void) 
{
	 if (EXTI_GetITStatus(EXTI_Line3) != RESET) {
		 if(mode==1)
		 {
			LED1n++;
		    if(LED1n==2) {
			 LED1n=0;
			PDout(14) ^=1;}
		 }
		 		 if(mode==3)
		 {
				while( GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_3)==0)
				{
					GPIO_SetBits(GPIOD,GPIO_Pin_14);
					 
				}mode=0;
				GPIO_ResetBits(GPIOD,GPIO_Pin_14);
				
		 }
		 		 if(mode==2)
		 {
				GPIO_ToggleBits(GPIOD,GPIO_Pin_14);
			
		 }

	 }
        EXTI_ClearITPendingBit(EXTI_Line3);
		 
}

void EXTI4_IRQHandler(void) 
{
    if (EXTI_GetITStatus(EXTI_Line4) != RESET) 
		{
			mode++;
			EXTI_ClearITPendingBit(EXTI_Line4);
    }
}