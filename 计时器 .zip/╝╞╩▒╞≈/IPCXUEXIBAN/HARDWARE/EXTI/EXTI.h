#ifndef __exti_H
#define __exti_H

#include "stm32f4xx.h"
#include "delay.h"

void exti_Init(void);


#endif //__BEE_H
